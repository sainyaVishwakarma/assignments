﻿namespace TPT.TrainingDemo.Infrastructure.Entities
{
    public class Employee
    {
        public int ENo{ get; set; }
        public string EName{ get; set; }
        public int EDeptId { get; set; }
    }
}