﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPT.TrainingDemo.Infrastructure.Entities
{
    public class Department
    {
        public int DNo { get; set; }
        public string DName { get; set; }
    }
}
