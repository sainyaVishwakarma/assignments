﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Logging;
using TPT.TrainingDemo.Domain;
using TPT.TrainingDemo.Infrastructure.Entities;

namespace TPT.TrainingDemo.Infrastructure.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {

        //      <connectionStrings>    
        //  <add name = "EmployeeContext" connectionString="data source=farhan; database=MvcDemo; integrated security=true;" providerName="System.Data.SqlClient"/>    
        //</connectionStrings> 
        private readonly SqlConnection _sqlConnection;
        private const string DB_CONNECTIONSTRING = "data source =localhost;Integrated Security=SSPI;database=ASSIGNMENT_DB;TrustServerCertificate=True";
        private readonly ILogger _logger;
        public EmployeeRepository(ILogger logger)
        {
            _logger = logger;
            _sqlConnection = new SqlConnection(DB_CONNECTIONSTRING);
        }
        public List<Domain.Employee> GetEmployees()
        {
            List<Domain.Employee> employees = new();
            try
            {
                using (_sqlConnection)
                {
                    SqlCommand sqlCommand = new SqlCommand("SELECT EMP.*,.DEPT.DName FROM EMP JOIN DEPT ON DEPT.DNo = EMP.EDep", _sqlConnection);
                    _sqlConnection.Open();
                    SqlDataReader reader = sqlCommand.ExecuteReader();
                    int numberofRecords = 0;
                    while (reader.Read())
                    {
                        Domain.Employee employee = new();

                        employee.Id = Convert.ToInt32(reader["ENo"]);
                        employee.Name = reader["EName"] != null ? reader["EName"].ToString() : "";
                        employee.Department = reader["DName"].ToString();
                        employee.DeptId = Convert.ToInt32(reader["EDep"]);
                        employees.Add(employee);
                        numberofRecords++;
                    }
                    _logger.LogInformation($"Found Employees count is {numberofRecords}");
                }

            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            return employees;
        }
    }
}
