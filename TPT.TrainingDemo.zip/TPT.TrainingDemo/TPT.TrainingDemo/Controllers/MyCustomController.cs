﻿using System.Net;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using TPT.TrainingDemo.Domain;
using TPT.TrainingDemo.Services;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TPT.TrainingDemo.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MyCustomController : ControllerBase
    {
        public IListGeneratorService _generator = null;

        public MyCustomController(IListGeneratorService generator)
        {
            _generator = generator;

        }

        // GET: api/<MyCustomController>
        [HttpGet]
        public IEnumerable<Employee> Get()
        {
            return _generator.GetList();
        }

        // GET api/<MyCustomController>/5
        [HttpGet("{id}")]
        public ActionResult<Employee> Get(int id)
        {
            if (id < 1 || id > 10)
            {
                // throw new ArgumentException("Invalid Index"Invalid Index
                return BadRequest("Invalid Index");
            }
            return _generator.GetList()[id - 1];
        }

        // POST api/<MyCustomController>
        [HttpPost]
        public Employee Post([FromBody] Employee e)
        {
            return _generator.Add(e);
        }

        // PUT api/<MyCustomController>/5
        [HttpPut("{id}")]
        public void UpdateEmployee(int id, Employee e)
        {
            //todo validations
            _generator.UpdateEmployee(id, e);

        }
        [HttpPatch]
        public IActionResult JsonPatchWithModelState(
    [FromBody] JsonPatchDocument<Employee> patchDocument)
        {
            if (patchDocument != null)
            {
                Employee e = _generator.GetList()[0];
                patchDocument.ApplyTo(e, ModelState);
                //Employee employee = _generator.PatchEmployee(patchEmployee);
                return new ObjectResult(e);
            }
            else
            {
                return BadRequest(ModelState);
            }
        }


        // DELETE api/<MyCustomController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
