using Microsoft.Extensions.Logging;
using TPT.TrainingDemo.Infrastructure.Repository;
using TPT.TrainingDemo.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers().AddNewtonsoftJson();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddTransient<IEmployeeRepository, EmployeeRepository>();
builder.Services.AddTransient<IListGeneratorService, ListGeneratorService>();
builder.Services.AddSingleton<ILogger, Logger<IEmployeeRepository>>();
//builder.Services.AddAuthentication(x =>
//{
//    x.DefaultAuthenticateScheme = "rutu";
//    x.DefaultChallengeScheme = "rutu";
//}).AddPolicyScheme("rutu", "RutuName", options =>
//{
//    options.ForwardDefaultSelector = context =>
//    {
//        var authHeader = context.Request.Headers["Authorization"].FirstOrDefault();
//        if (authHeader != null)
//        {
//            return "RutuAuthentication";
//        }
//    };
//});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();
//app.Run(async context =>
//{
//    var str = context.Request.HttpContext.Request.QueryString.Value;
//    if (str != null && str.Contains("Rutu"))
//    {

//        await context.Response.WriteAsync("Testing it");
//    }
   
//});

app.Run();
