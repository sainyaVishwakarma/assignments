﻿using Microsoft.AspNetCore.JsonPatch;
using TPT.TrainingDemo.Domain;

namespace TPT.TrainingDemo.Services
{
    public class ListGenerator : IListGenerator
    {
        readonly List<string> cities = new()
            {
                "Pune",
                "Delhi",
                "Mumbai",
                "Chennai",
                "Kolkata"
            };
        List<Employee> _employees = new();
        int BASE_ID = 0;
        public ListGenerator()
        {
            GenerateList();
        }


        public void AddEmployee(Employee employee)
        {
            _employees.Add(employee);
        }

        void GenerateList()
        {
            for (int i = 0; i < 10; i++)
            {
                _employees.Add(new Employee()
                {
                    City = cities[i > 4 ? i / 2 : i],
                    Name = "EMP" + (i + 1).ToString(),
                    Id = ++BASE_ID,
                });
            }

        }

        public List<Employee> GetList()
        {
            return _employees;
        }

        public Employee Add(Employee e)
        {
            _employees.Add(e);
            return e;
        }

        public void UpdateEmployee(int id, Employee e)
        {
            var employee = _employees.First(e => e.Id == id);
            if (employee != null)
            {
                employee.Name = e.Name;
                employee.City = e.City;
            }
        }

        //public Employee PatchEmployee(JsonPatchDocument<Employee> patchEmployee)
        //{
        //    var customer = CreateCustomer();

        //    patchEmployee.ApplyTo(_employees, ModelState);
        //}
    }
}