﻿using Microsoft.AspNetCore.JsonPatch;
using Microsoft.Extensions.Logging;
using TPT.TrainingDemo.Domain;
using TPT.TrainingDemo.Infrastructure.Repository;

namespace TPT.TrainingDemo.Services
{
    public class ListGeneratorService : IListGeneratorService
    {
        readonly List<string> cities = new()
            {
                "Pune",
                "Delhi",
                "Mumbai",
                "Chennai",
                "Kolkata"
            };
        List<Employee> _employees = new();
        IEmployeeRepository _employeeRepository;
        ILogger<EmployeeRepository> _logger;
        int BASE_ID = 0;
        public ListGeneratorService(ILogger<EmployeeRepository> logger, IEmployeeRepository employeeRepository)
        {
            //GenerateList();
            _logger = logger;
            _employeeRepository = employeeRepository;
        }


        public void AddEmployee(Employee employee)
        {

            _employees.Add(employee);
        }

        void GenerateList()
        {
            for (int i = 0; i < 10; i++)
            {
                _employees.Add(new Employee()
                {
                    Department = cities[i > 4 ? i / 2 : i],
                    Name = "EMP" + (i + 1).ToString(),
                    Id = ++BASE_ID,
                });
            }

        }

        public List<Employee> GetList()
        {
            _logger.LogInformation("Fetching data from DB");
            _logger.LogError("Invalid Input");
            return _employeeRepository.GetEmployees();
        }

        public Employee Add(Employee e)
        {
            _employees.Add(e);
            return e;
        }

        public void UpdateEmployee(int id, Employee e)
        {
            var employee = _employees.First(e => e.Id == id);
            if (employee != null)
            {
                employee.Name = e.Name;
                employee.Department = e.Department;
            }
        }

        //public Employee PatchEmployee(JsonPatchDocument<Employee> patchEmployee)
        //{
        //    var customer = CreateCustomer();

        //    patchEmployee.ApplyTo(_employees, ModelState);
        //}
    }
}