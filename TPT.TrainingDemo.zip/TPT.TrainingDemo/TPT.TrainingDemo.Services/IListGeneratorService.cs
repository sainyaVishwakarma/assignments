﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.JsonPatch;
using TPT.TrainingDemo.Domain;

namespace TPT.TrainingDemo.Services
{
    public interface IListGeneratorService
    {
    
        public List<Employee> GetList();
        public Employee Add(Employee e);
        void UpdateEmployee(int id, Employee e);
       // Employee PatchEmployee(JsonPatchDocument<Employee> patchEmployee);
    }
}
