﻿using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using TPT.Assignment4.Domain;

namespace TPT.Assignment4.Infrastructure.Repository
{
    public class InvoiceRepository : IInvoiceRepository
    {
        private readonly SqlConnection _sqlConnection;
        private const string connectionString = "Data Source=TINPNQ-DW1-0045;Database=CSHARPASSIGNMENT_DB;Integrated Security = True; Connect Timeout = 30; Encrypt=False;Trust Server Certificate=False;Application Intent = ReadWrite; Multi Subnet Failover=False";
        public InvoiceRepository()
        {
            _sqlConnection = new SqlConnection(connectionString);
        }

        public Invoice AddInvoice(Invoice invoice)
        {
            try
            {
                using (_sqlConnection)
                {
                    string query1 = "INSERT INTO INVOICE(InvoiceDate,CustomerCode,Amount) VALUES(@InvoiceDate,@CustomerCode,@Amount)";
                    string query2 = "SELECT InvoiceNo FROM INVOICE WHERE InvoiceDate=@InvoiceDate";
                    SqlCommand cmd1 = new SqlCommand(query1, _sqlConnection);
                    SqlCommand cmd2 = new SqlCommand(query2, _sqlConnection);
                    _sqlConnection.Open();
                    cmd1.Parameters.AddWithValue("@InvoiceDate", invoice.InvoiceDate);
                    cmd1.Parameters.AddWithValue("@CustomerCode", invoice.CustomerCode);
                    cmd1.Parameters.AddWithValue("@Amount", invoice.Amount);
                    cmd2.Parameters.AddWithValue("@InvoiceDate", invoice.InvoiceDate);
                    int totalRowsAffected=cmd1.ExecuteNonQuery();
                    if(totalRowsAffected > 0) {
                      Console.WriteLine($"{totalRowsAffected} Affected Successfully!");
                    }
                    SqlDataReader reader = cmd2.ExecuteReader();
                    while (reader.Read())
                    {
                        invoice.InvoiceNo = Convert.ToInt32(reader["InvoiceNo"]);
                    }
                    invoice.Status = "unpaid";
                }
            }catch (SqlException ex)
            {
                Console.WriteLine(ex.ToString());
            }catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return invoice;
        }

        public string ConfirmPayment(int invoiceNo)
        {
            String isConfirmed = "";
            try
            {
                using (_sqlConnection)
                {
                    SqlCommand cmd = new SqlCommand("SP_MOVEINVOICETOARCHIVED", _sqlConnection)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    _sqlConnection.Open();
                    SqlParameter param = new SqlParameter
                    {
                        ParameterName = "@InvoiceNo",
                        SqlDbType = SqlDbType.Int,
                        Value = invoiceNo,
                        Direction = ParameterDirection.Input,
                    };
                    cmd.Parameters.Add(param);
                    int result= cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        isConfirmed += "Payment Confirmed!";
                        
                    }
                    else
                    {
                        isConfirmed += "Payment not Confirmed!";
                        
                    }

                }
            }catch(SqlException ex)
            {
                Console.WriteLine(ex.ToString());
            }catch(Exception ex) {
                Console.WriteLine(ex.ToString());
            }
            return isConfirmed;
        }

        public List<Invoice> GetInvoices(string searchText, string? status)
        {
            List<Invoice> invoices = new();
            try
            {
                using (_sqlConnection)
                {
                    SqlCommand cmd = null;
                    if (status == "paid")
                    {
                        cmd = new SqlCommand("SELECT * FROM ARCHIVEDINVOICE WHERE SUBSTRING(CUSTOMERCODE,1,2)=@searchText", _sqlConnection);
                    }
                    else if (status == "unpaid")
                    {
                        cmd = new SqlCommand("SELECT * FROM INVOICE WHERE SUBSTRING(CUSTOMERCODE,1,2)=@searchText", _sqlConnection);
                    }
                    else if (status == null)
                    {
                        cmd = new SqlCommand("SELECT * FROM INVOICE WHERE SUBSTRING(CUSTOMERCODE,1,2) = @searchText " +
                            "UNION SELECT * FROM ARCHIVEDINVOICE WHERE SUBSTRING(CUSTOMERCODE,1,2)=@searchText", _sqlConnection);
                    }
                    
                    _sqlConnection.Open();
                    cmd.Parameters.AddWithValue("@searchText", searchText);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        Invoice invoice = new();

                        invoice.InvoiceDate = (DateTime)reader["InvoiceDate"];
                        invoice.InvoiceNo = Convert.ToInt32(reader["InvoiceNo"]);
                        invoice.CustomerCode = reader["CustomerCode"].ToString();
                        invoice.Amount = Convert.ToInt32(reader["Amount"]);
                        invoice.Status = status;
                        invoices.Add(invoice);
                        
                    }
                }
            }catch(SqlException ex)
            {
                Console.WriteLine(ex.ToString());
            }catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            return invoices;
        }
    }
}
