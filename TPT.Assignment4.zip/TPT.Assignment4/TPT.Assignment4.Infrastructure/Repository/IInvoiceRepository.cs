﻿using TPT.Assignment4.Domain;

namespace TPT.Assignment4.Infrastructure.Repository
{
    public interface IInvoiceRepository
    {
        Invoice AddInvoice(Invoice invoice);
        string ConfirmPayment(int invoiceNo);
        List<Invoice> GetInvoices(string searchText, string status);
    }
}
