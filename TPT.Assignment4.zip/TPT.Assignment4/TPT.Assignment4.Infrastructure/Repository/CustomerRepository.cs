﻿using Microsoft.Data.SqlClient;
using TPT.Assignment4.Domain;

namespace TPT.Assignment4.Infrastructure.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly SqlConnection _sqlConnection;
        private const string connectionString = "Data Source=TINPNQ-DW1-0045;Database=CSHARPASSIGNMENT_DB;Integrated Security = True; Connect Timeout = 30; Encrypt=False;Trust Server Certificate=False;Application Intent = ReadWrite; Multi Subnet Failover=False";
        public CustomerRepository()
        {
            _sqlConnection = new SqlConnection(connectionString);
        }

        public Customer AddCustomer(Customer customer)
        {
            try
            {
                using (_sqlConnection)
                {
                    SqlCommand command = new SqlCommand("INSERT INTO CUSTOMER (FirstName,LastName,CustomerCode) VALUES(@FirstName,@LastName,@CustomerCode)", _sqlConnection);
                    _sqlConnection.Open();
                    command.Parameters.AddWithValue("@CustomerCode", customer.CustomerCode);
                    command.Parameters.AddWithValue("@FirstName", customer.FirstName);
                    command.Parameters.AddWithValue("@LastName", customer.LastName);
                    int totalRowsAffected = command.ExecuteNonQuery();
                    if (totalRowsAffected > 0)
                    {
                        Console.WriteLine($"{totalRowsAffected} Affected Successfully!");
                    }
                }

            }
            catch(SqlException e)
            {
                Console.WriteLine(e.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return customer;
        }

        
    }
}
