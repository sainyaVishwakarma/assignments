﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPT.Assignment4.Domain;

namespace TPT.Assignment4.Infrastructure.Repository
{
    public interface ICustomerRepository
    {
        Customer AddCustomer(Customer customer);
        
    }
}
