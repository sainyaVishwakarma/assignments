﻿namespace TPT.Assignment4.Domain
{
    public class Invoice
    {
        private DateTime invoiceDate;
        public DateTime InvoiceDate
        {
            get { return invoiceDate; }
            set { invoiceDate = value; }
        }
        public int InvoiceNo {  get; set; }
        public string CustomerCode {  get; set; }
        public decimal Amount { get; set; }

        public string? Status { get; set; }
        
        public Invoice() { }

        public Invoice(  string customerCode, decimal amount, string status)
        {
            invoiceDate = DateTime.Now;
            CustomerCode = customerCode;
            Amount = amount;
            Status = status;
        }

        public Invoice(string customerCode, decimal amount)
        {
            invoiceDate = DateTime.Now;
            CustomerCode = customerCode;
            Amount = amount;
            
        }
    }
}
