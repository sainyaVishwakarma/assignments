﻿namespace TPT.Assignment4.Domain
{
    public class Customer
    {
        private static int _id = 101;
        public string FirstName { get; set; }
        public string LastName { get; set; }

        private string customerCode;
        public  string CustomerCode {

            get {
                return customerCode;
                }
            set {
                customerCode= value;
            }
        }
        public Customer() { }
        public Customer(string firstName,string lastName) {
            FirstName = firstName;
            LastName = lastName;
            customerCode= ($"{FirstName.Substring(0, 1).ToUpper()}{LastName.Substring(0, 1).ToUpper()}") + _id++;
        }
    }
}