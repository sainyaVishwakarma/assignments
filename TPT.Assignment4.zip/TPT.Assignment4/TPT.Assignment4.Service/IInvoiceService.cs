﻿using TPT.Assignment4.Domain;

namespace TPT.Assignment4.Service
{
    public interface IInvoiceService
    {
        List<Invoice> GetInvoices(string searchText,string status);

        Invoice AddInvoice(string customerCode,decimal amount);

        string ConfirmPayment(int invoiceNo);


    }
}
