﻿using TPT.Assignment4.Domain;
using TPT.Assignment4.Infrastructure.Repository;

namespace TPT.Assignment4.Service
{
    public class InvoiceService : IInvoiceService
    {
        private readonly IInvoiceRepository _invoiceRepository;
        public InvoiceService(IInvoiceRepository invoiceRepository) {
            _invoiceRepository = invoiceRepository;
        }
        public Invoice AddInvoice(string customerCode, decimal amount)
        {
            return _invoiceRepository.AddInvoice(new Invoice(customerCode, amount));
        }

        public string ConfirmPayment(int invoiceNo)
        {
            return _invoiceRepository.ConfirmPayment(invoiceNo);
        }

        public List<Invoice> GetInvoices(string searchText, string status)
        {
            return _invoiceRepository.GetInvoices(searchText,status);
        }
    }
}