﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPT.Assignment4.Domain;
using TPT.Assignment4.Infrastructure.Repository;

namespace TPT.Assignment4.Service
{
    public class CustomerService : ICustomerService
    {   
        private readonly ICustomerRepository _customerRepository;
        public CustomerService(ICustomerRepository customerRepository) {
            _customerRepository= customerRepository;
        }
        public Customer AddCustomer(string firstName, string lastName)
        {

            Customer customer = new Customer(firstName, lastName);
            return _customerRepository.AddCustomer(customer);
            
        }

    }
}
