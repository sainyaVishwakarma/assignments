﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TPT.Assignment4.Domain;

namespace TPT.Assignment4.Service
{
    public interface ICustomerService
    {
        Customer AddCustomer(string firstName, string lastName);
       
    }
}
