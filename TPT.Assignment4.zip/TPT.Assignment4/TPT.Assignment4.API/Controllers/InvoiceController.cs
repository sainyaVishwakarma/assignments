﻿using Microsoft.AspNetCore.Mvc;
using System.Text.RegularExpressions;
using TPT.Assignment4.Domain;
using TPT.Assignment4.Service;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TPT.Assignment4.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private readonly IInvoiceService _invoiceService;
        public InvoiceController(IInvoiceService invoiceService)
        {
            _invoiceService = invoiceService;
        }

        // GET: api/<InvoiceController>
        [HttpGet]
        public ActionResult<List<Invoice>> GetInvoices(string searchText,string status=null)
        {
            var regex = "^[a-zA-Z]{2}";
            if(!Regex.IsMatch(searchText, regex))
            {
                return BadRequest("Invoices not found!");
            }
            List<Invoice> invoices = _invoiceService.GetInvoices(searchText, status);
            if(invoices.Count == 0)
            {
                return BadRequest("Invoices not found!");
            }
            
            return Ok(invoices);
        }



        // POST api/<InvoiceController>
        [HttpPost]
        public ActionResult<Invoice> AddInvoice(string customerCode, decimal amount)
        {
            if(customerCode == null)
            {
                return NotFound("Customer not found!");
            }
           
            Invoice invoice= _invoiceService.AddInvoice(customerCode, amount);
            return Ok(invoice);
        }

        [HttpGet("/confirmpayment")]
        public ActionResult<string>  ConfirmPayment(int invoiceNo)
        {
            if(invoiceNo == 0)
            {
                return BadRequest("InvoiceNo not found!");
            }
            string s=_invoiceService.ConfirmPayment(invoiceNo);
            return Ok(s);
        }

      
    }
}
