﻿using Microsoft.AspNetCore.Mvc;
using System.Text.RegularExpressions;
using TPT.Assignment4.Domain;
using TPT.Assignment4.Service;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TPT.Assignment4.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerService _customerService;

        public CustomerController(ICustomerService customerService)
        {
            _customerService= customerService;
        }
       

        // POST api/<CustomerController>
        [HttpPost]
        public ActionResult<Customer> Add(string firstName,string lastName)
        {   
            if(firstName == null || lastName == null) { 
                return BadRequest(string.Empty);
            }
            var regex = "^[a-zA-Z]{1,25}";
            if ((!Regex.IsMatch(firstName,regex)) || (!Regex.IsMatch(firstName, regex)))
            {
                return BadRequest("First Name and Last Name should not contains more than 25 characters!!");
            }
            Customer customer = _customerService.AddCustomer(firstName, lastName);
            if(customer == null)
            {
                return NotFound();
            }
            return Ok(customer);
        }

    }
}
